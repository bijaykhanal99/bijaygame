function back() {
window.history.back();
}
function ntew(){
  window.location.href = "new.html";
}
function neww() {
  window.location.href = "neww.html";
}
function newww() {
  window.location.href = "newww.html";
}
function birt() {
  window.location.href = "https://bijaykhanal08.github.io/bijaykhanal088/";
}